import { initializeApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAVq3PgXTso7kKKHbxiLVr8vVEJXvaCLxk",

  authDomain: "taxihaiphong24h.firebaseapp.com",

  projectId: "taxihaiphong24h",

  storageBucket: "taxihaiphong24h.appspot.com",

  messagingSenderId: "764925217758",

  appId: "1:764925217758:web:7f409b08a77312bc3feb4f",

  measurementId: "G-5GJL2JB2R7",
};

const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});

export const auth = getAuth(app);
